<?php
$server =	"PMYSQL108.dns-servicio.com";
$db		=	"6705937_sar";
$user 	=	"sar2020";
$pass 	=	"&&wqj13T1#1//";
?>